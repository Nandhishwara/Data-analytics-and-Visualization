
		--DATA PREPARATION AND UNDERSTANDING
--Q1--BEGIN
	--1. What is the total number of rows in each of the 3 tables in the database?

	SELECT COUNT(*) Customer_Row_count FROM Customer
	SELECT COUNT(*) Transactions_Row_count FROM Transactions
	SELECT COUNT(*) prod_cat_info_Row_count FROM prod_cat_info;

--Q1--END
	 
--Q2--BEGIN
	--2.  What is the total number of Transactions that have a return?
	
	SELECT COUNT(CAST(total_amt AS float)) Returns_amt FROM Transactions
	WHERE CAST(total_amt AS float) < 0 ;

--Q2--END
	
--Q3--BEGIN
	--3. As you would have noticed,the dates provided across the datasets are not in a correct format. As first steps,pis convert the date variables into valid date formats before proceeding ahead.
	
	SELECT customer_Id,CONVERT(VARCHAR,DOB,103) fromated_date,Gender,city_code  FROM Customer;

--Q3--END
	
--Q4--BEGIN
	--4. What is the time range of the Transact ion data available for analysis? Show the output in number of days,months and years simultaneous ly in different columns.
	
	SELECT DATEDIFF(YEAR,MIN(Tran_date),MAX(Tran_date))YEAR_DIFF,
	DATEDIFF(MONTH,MIN(Tran_date),MAX(Tran_date))MONTH_DIFF,
	DATEDIFF(DAY,MIN(Tran_date),MAX(Tran_date)) DAY_DIFF
	FROM Transactions

--Q4--END
	
--Q5--BEGIN
	--5.  Which product category does the sub-category ""DIV"" belong to?
	
	SELECT prod_cat FROM prod_cat_info
	WHERE prod_subcat LIKE '%DIY%';

--Q5--END
	


		--DATA ANALYSIS
--Q1--BEGIN
	--1.  Which channel is most frequently used for Transactions?

	SELECT TOP 1 Store_type,COUNT(Store_type) AS value_occurrence
	FROM Transactions
	GROUP BY Store_type
	ORDER BY value_occurrence DESC 
	
--Q1--END

--Q2--BEGIN
	--2. What is the count of Male and Female customers in the database?

	SELECT
	SUM(CASE WHEN Gender = 'M' THEN 1 ELSE 0 END) as 'Male Count',
	SUM(CASE WHEN Gender = 'F' THEN 1 ELSE 0 END) as 'Female Count',
	COUNT(*) as TotalCount
	FROM Customer
	
--Q2--END

--Q3--BEGIN
	--3.  From which city do we have the maximum number of customers and how many?
	
	SELECT TOP(1) COUNT(city_code) customer_count_by_city,city_code 
	FROM Customer
	GROUP BY city_code
	ORDER BY COUNT(city_code) DESC;

--Q3--END

--Q4--BEGIN
	--4.  How many sub-categories are there under the Books category?
	
	SELECT COUNT(prod_subcat) count_of_subcat 
	FROM prod_cat_info
	WHERE prod_cat = 'Books';
--Q4--END

--Q5--BEGIN
	--5. What is the maximum quantity of products ever ordered?
	
	SELECT MAX(Qty)max_qty_product 
	FROM Transactions
	GROUP BY prod_cat_code;

--Q5--END

--Q6--BEGIN
	--6.  What is the net total revenue generated in categories ElecTronics and Books?
	
	SELECT SUM(CAST(total_amt AS float)) net_total_revenue_generated,prod_cat 
	FROM Transactions TR
	LEFT JOIN prod_cat_info PC
	ON TR.prod_cat_code = PC.prod_cat_code
	WHERE prod_cat = 'ElecTronics' or prod_cat = 'Books'
	GROUP BY prod_cat;

--Q6--END
	
--Q7--BEGIN
	--7.  How many customers have >10 Transactions with us, excluding returns?
	
	SELECT  COUNT(cust_id) Tx_count,cust_id 
	FROM Transactions
	WHERE CAST(total_amt AS float) > 0
	GROUP BY cust_id
	HAVING COUNT(cust_id) > 10;

--Q7--END

--Q8--BEGIN
	--8. What  is the combined revenue earned from the ""ElecTronics"" & ""Clothing"" categories,from ""Flagship stores""?
	
	SELECT SUM(CAST(total_amt AS float)) revenue 
	FROM Transactions TR
	LEFT JOIN prod_cat_info PC
	ON TR.prod_cat_code = PC.prod_cat_code
	WHERE prod_cat IN ('ElecTronics','Clothing') AND Store_type = 'Flagship store'

--Q8--END

--Q9--BEGIN
	--9.  What  is the total revenue generated  from  ""Male""  customers  in ""ElecTronics"" category? Output should display total revenue by prod sub-cat.
	
	SELECT SUM(CAST(total_amt AS float))total_revenue,prod_subcat 
	FROM Transactions TR
	RIGHT JOIN Customer CU
	ON CU.customer_Id = TR.cust_id
	LEFT JOIN prod_cat_info PC
	ON TR.prod_cat_code = PC.prod_cat_code
	WHERE Gender = 'M' AND PC.prod_cat =  'ElecTronics'
	GROUP BY prod_subcat;

--Q9--END

--Q10--BEGIN
	--10.What is percentage of sales and returns by product sub category; display only top 5 sub categories in terms of sales?

   SELECT TOP 5
     P.prod_subcat [Subcategory] ,
	 Round(SUM(cast( CASE WHEN T.Qty > 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)[Sales]  , 
	 Round(SUM(cast( CASE WHEN T.Qty < 0 THEN T.Qty ELSE 0 END AS FLOAT)),2) [Returns] ,
	 Round(SUM(cast( CASE WHEN T.Qty > 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)
                 - Round(SUM(cast( CASE WHEN T.Qty < 0 THEN T.Qty   ELSE 0 END AS FLOAT)),2)[total_qty],
     ((Round(SUM(cast( CASE WHEN T.Qty < 0 then T.Qty  else 0 end as float)),2))/
                  (Round(SUM(cast( CASE WHEN T.Qty > 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)
                 - Round(SUM(cast( CASE WHEN T.Qty < 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)))*100[%_Returs],
     ((Round(SUM(cast( CASE WHEN T.Qty > 0 THEN T.Qty  ELSE 0 END AS FLOAT)),2))/
                  (Round(SUM(cast( CASE WHEN T.Qty > 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)
                 - Round(SUM(cast( CASE WHEN T.Qty < 0 THEN T.Qty ELSE 0 END AS FLOAT)),2)))*100[%_sales]
     FROM Transactions AS T
     INNER JOIN prod_cat_info AS P ON T.prod_subcat_code = P.prod_sub_cat_code
     GROUP BY P.prod_subcat
     ORDER BY [%_sales] DESC

--Q10--END

--Q11--BEGIN
	--11.For all customers aged between 25 to 35 years find what is the net total revenuegenerated by these consumers in last 30 days of Transactions from max Transaction date available in the data?
	
	SELECT SUM(CONVERT(FLOAT,total_amt)) net_total_revenue 
	FROM Transactions TR
	JOIN Customer CU
	ON TR.cust_id = CU.customer_Id
	WHERE
	DATEDIFF(YEAR,DOB,GETDATE()) BETWEEN 25 AND 35
	AND DATEDIFF(DAY,CONVERT(DATE, TR.Tran_date,105),(SELECT MAX(TR.Tran_date)  
	FROM Transactions TR)) <= 30

--Q11--END

--Q12--BEGIN
	--12. Which product category has seen the max value of returns in the last 3 months of Transactions?
	
	SELECT prod_cat_code,MAX(CONVERT(FLOAT,total_amt)) Returns_amt 
	FROM Transactions T1
	WHERE CONVERT(FLOAT,total_amt) < 0
	AND DATEDIFF(MONTH,convert(date, T1.tran_date,105),(SELECT MAX(T3.tran_date)  
	FROM Transactions T3)) < 3
	GROUP BY prod_cat_code
	ORDER BY Returns_amt

--Q12--END

--Q13--BEGIN
	--13.Which store-type sells the maximum products; by value of sa les amount and by quantity sold?
	
	SELECT  TOP(1) Store_type  
	FROM Transactions
	GROUP BY Store_type
	ORDER BY (SUM(CONVERT(FLOAT,total_amt)) / SUM(CONVERT(INT,Qty))) DESC 

--Q13--END

--Q14--BEGIN
	--14.What are the categories for which average revenue is above the overall average.
	
	SELECT * 
	FROM (SELECT PC.prod_cat ,AVG(CONVERT(FLOAT,total_amt)) Avg_revenue 
	FROM Transactions TR
	JOIN prod_cat_info PC
	ON TR.prod_cat_code = PC.prod_cat_code
	GROUP BY PC.prod_cat)SQ1
	WHERE SQ1.Avg_revenue > (SELECT AVG(CONVERT(FLOAT,total_amt)) 
	FROM Transactions)

--Q14--END

--Q15--BEGIN
	--15. Find the average and total revenue by each subcategory for the categories which are among top 5 categories in terms of quant ity sold.
	
	SELECT P.prod_subcat AS Product_SubCategory, 
	AVG(CAST(total_amt AS FLOAT)) AS Average_Revenue,
	SUM(CAST(total_amt AS FLOAT)) AS Total_Revenue
	from Transactions AS T
	INNER JOIN prod_Cat_info AS P
	ON T.prod_cat_code = P.prod_cat_code AND T.prod_subcat_code = 
	P.prod_sub_cat_code
	WHERE P.prod_cat_code IN (
	SELECT TOP 5 P.prod_cat_code
	FROM prod_cat_info AS P
	INNER JOIN Transactions AS T
	ON P.prod_cat_code = T.prod_cat_code AND P.prod_sub_cat_code = 
	T.prod_subcat_code
	GROUP BY P.prod_cat_code
	ORDER BY sum(Cast(Qty AS INT)) DESC
	)
	GROUP BY P.prod_subcat





--Q15--END

	
	
	
