--SQL Advance Case Study


--Q1--BEGIN 
	--1. List all the states in which we have customers who have bought cellphones from 2005 till today.
	
	SELECT YEAR,DL.State
	FROM DIM_LOCATION DL
	LEFT JOIN FACT_TRANSACTIONS FT
	ON DL.IDLocation = FT.IDLocation
	LEFT JOIN DIM_DATE DD
	ON FT.Date = DD.DATE
	WHERE DD.YEAR >= '2005' ;

--Q1--END

--Q2--BEGIN
	--2. What state in the US is buying the most 'Samsung' cell phones?
	
	SELECT DL.State
	FROM DIM_LOCATION DL
	LEFT JOIN FACT_TRANSACTIONS FT
	ON DL.IDLocation = FT.IDLocation
	LEFT JOIN DIM_MODEL DMO
	ON FT.IDModel = DMO.IDModel
	LEFT JOIN DIM_MANUFACTURER DMA
	ON DMO.IDManufacturer = DMA.IDManufacturer
	WHERE DMA.Manufacturer_Name = 'Samsung';

--Q2--END

--Q3--BEGIN      
	--3. Show the number of transactions for each model per zip code per state.
	
	SELECT DL.ZipCode,DL.State,DMO.Model_Name,DMO.IDModel,COUNT(DMO.IDModel) AS No_Of_Transactions
	FROM DIM_LOCATION DL
	LEFT JOIN FACT_TRANSACTIONS FT
	ON DL.IDLocation = FT.IDLocation
	LEFT JOIN DIM_MODEL DMO
	ON FT.IDModel = DMO.IDModel
	GROUP BY DL.ZipCode,DMO.IDModel,DMO.Model_Name,DL.State;

--Q3--END

--Q4--BEGIN
	--4. Show the cheapest cellphone (Output should contain the price also)
	
	SELECT DMA.Manufacturer_Name,DMO.Model_Name,DMO.Unit_price
	FROM DIM_MODEL DMO
	INNER JOIN DIM_MANUFACTURER DMA
	ON DMO.IDManufacturer = DMA.IDManufacturer
	WHERE Unit_price =
	(SELECT MIN(Unit_price) FROM DIM_MODEL)

--Q4--END

--Q5--BEGIN
	--5. Find out the average price for each model in the top5 manufacturers in terms of sales quantity and order by average price. 

	SELECT  FT.IDModel,DMO.Model_Name,AVG(FT.TotalPrice) average_price 
	FROM FACT_TRANSACTIONS FT 
	LEFT JOIN DIM_MODEL DMO
	ON FT.IDModel = DMO.IDModel
	WHERE FT.IDModel IN 
	(
	SELECT DMO.IDModel 
	FROM DIM_MODEL DMO 
	WHERE DMO.IDManufacturer IN 
	(
	SELECT TOP(5) T2.IDManufacturer 
	FROM 
	(
	SELECT SUM(T1.Total_Qantity) Quantity,DMO.IDManufacturer 
	FROM 
	(
	SELECT FT.IDModel,SUM(Quantity) Total_Qantity
	FROM FACT_TRANSACTIONS FT
	GROUP BY FT.IDModel) T1
	RIGHT JOIN DIM_MODEL DMO
	ON T1.IDModel = DMO.IDModel
	GROUP BY DMO.IDManufacturer) T2
	ORDER BY T2.Quantity DESC)) 
	GROUP BY FT.IDModel,DMO.Model_Name
	ORDER BY average_price;

--Q5--END

--Q6--BEGIN
	--6. List the names of the customers and the average amount spent in 2009, where the average is higher than 500
	
	SELECT DC.IDCustomer,DC.Customer_Name, AVG(FT.TotalPrice) AS AVG_PRICE
	FROM DIM_CUSTOMER DC
	LEFT JOIN FACT_TRANSACTIONS FT
	ON DC.IDCustomer = FT.IDCustomer
	INNER JOIN DIM_DATE DD
	ON FT.Date = DD.DATE
	WHERE DD.YEAR = '2009' 
	GROUP BY DC.IDCustomer,DC.Customer_Name
	HAVING  AVG(TotalPrice) > '500'	

--Q6--END
	
--Q7--BEGIN  
	--7. List if there is any model that was in the top 5 in terms of quantity, simultaneously in 2008, 2009 and 2010 
	
	SELECT * 
	FROM 
	(
	SELECT 
    TOP 5 IDModel
    FROM Fact_Transactions 
    WHERE DATEPART(YEAR,DATE)='2008' 
    GROUP BY IDModel, Quantity 
    ORDER BY  SUM(Quantity ) DESC  
    INTERSECT
	SELECT  TOP 5 IDModel
    FROM Fact_Transactions 
	WHERE DATEPART(YEAR,DATE)='2009' 
	GROUP BY IDModel, Quantity 
    ORDER BY  SUM(Quantity ) DESC  
    INTERSECT
	SELECT TOP 5 IDModel
    FROM Fact_Transactions 
    WHERE DATEPART(YEAR,DATE)='2010' 
    GROUP BY IDModel, Quantity 
    ORDER BY  SUM(Quantity ) DESC)  as A

	
--Q7--END	
--Q8--BEGIN
	--8. Show the manufacturer with the 2nd top sales in the year of 2009 and the manufacturer with the 2nd top sales in the year of 2010.
	
	SELECT SQ.Manufacturer_Name,Year_1 
	FROM
	(SELECT SQ2.Manufacturer_Name,SUM(SQ2.Total_sales) Total,Year_1,ROW_NUMBER() OVER (ORDER BY SUM(SQ2.Total_sales) DESC) ROW 
	FROM 
	(SELECT Manufacturer_Name,T2.IDModel,SUM(T1.Totalprice) Total_sales,ROW_NUMBER() OVER (ORDER BY SUM(TotalPrice) DESC) AS ROW_NO, YEAR(T1.Date) Year_1
	FROM DIM_MODEL T2
	LEFT JOIN FACT_TRANSACTIONS T1
	ON T2.IDModel = T1.IDModel
	LEFT JOIN DIM_MANUFACTURER T3
	ON T2.IDManufacturer = T3.IDManufacturer
	WHERE YEAR(T1.Date) = 2009
	GROUP BY Manufacturer_Name,T2.IDModel,YEAR(T1.Date)) SQ2
	GROUP BY SQ2.Manufacturer_Name,Year_1)SQ
	WHERE ROW = 2
	UNION 
	SELECT SQ.Manufacturer_Name,Year_2 
	FROM
	(SELECT SQ2.Manufacturer_Name,SUM(SQ2.Total_sales) Total,Year_2,ROW_NUMBER() OVER (ORDER BY SUM(SQ2.Total_sales) DESC) ROW 
	FROM 
	(SELECT Manufacturer_Name,T2.IDModel,SUM(T1.Totalprice) Total_sales, 
	ROW_NUMBER() OVER (ORDER BY SUM(TotalPrice) DESC) AS ROW_NO, YEAR(T1.Date) Year_2
	FROM DIM_MODEL T2
	LEFT JOIN FACT_TRANSACTIONS T1
	ON T2.IDModel = T1.IDModel
	LEFT JOIN DIM_MANUFACTURER T3
	ON T2.IDManufacturer = T3.IDManufacturer
	WHERE YEAR(T1.Date) = 2010
	GROUP BY Manufacturer_Name,T2.IDModel,YEAR(T1.Date)) SQ2
	GROUP BY SQ2.Manufacturer_Name,Year_2)SQ
	WHERE ROW = 2;

--Q8--END
--Q9--BEGIN
	--9. Show the manufacturers that sold cellphones in 2010 but did not in 2009.

	SELECT IDManufacturer, YEAR 
	FROM (SELECT DISTINCT(IDManufacturer), SQ1.YEAR 
	FROM (SELECT T1.YEAR, T2.IDModel 
	FROM DIM_DATE T1
	RIGHT JOIN FACT_TRANSACTIONS T2
	ON T1.DATE = T2.Date
	WHERE YEAR = 2010) SQ1
	LEFT JOIN DIM_MODEL T3
	ON SQ1.IDModel = T3.IDModel) SQ2 
	WHERE IDManufacturer NOT IN (
	SELECT DISTINCT(IDManufacturer) 
	FROM (SELECT  T1.YEAR, T2.IDModel 
	FROM DIM_DATE T1
	RIGHT JOIN FACT_TRANSACTIONS T2
	ON T1.DATE = T2.Date
	WHERE YEAR = 2009) SQ3
	LEFT JOIN DIM_MODEL T3
	ON SQ3.IDModel = T3.IDModel);

--Q9--END

--Q10--BEGIN
--10. Find top 100 customers and their average spend, average quantity by each year. Also find the percentage of change in their spend.

	SELECT 
    T1.Customer_Name, T1.Year, T1.Avg_Price,T1.Avg_Qty,
    CASE
        WHEN T2.Year IS NOT NULL
        THEN FORMAT(CONVERT(DECIMAL(8,2),(T1.Avg_Price-T2.Avg_Price))/CONVERT(DECIMAL(8,2),T2.Avg_Price),'p') 
		ELSE NULL 
        END AS 'YEARLY_%_CHANGE'
    FROM
        (
		SELECT DC.Customer_Name, YEAR(FT.DATE) AS YEAR, AVG(FT.TotalPrice) AS Avg_Price, AVG(FT.Quantity) AS Avg_Qty 
		FROM FACT_TRANSACTIONS AS FT 
        LEFT JOIN DIM_CUSTOMER AS DC ON FT.IDCustomer=DC.IDCustomer
        WHERE FT.IDCustomer IN 
		(
		SELECT TOP 10 IDCustomer 
		FROM FACT_TRANSACTIONS 
		GROUP BY IDCustomer 
		ORDER BY SUM(TotalPrice) DESC)
        GROUP BY DC.Customer_Name, YEAR(FT.DATE)
        )T1
    LEFT JOIN
        (SELECT DC.Customer_Name, YEAR(FT.DATE) AS YEAR, AVG(FT.TotalPrice) AS Avg_Price, AVG(FT.Quantity) AS Avg_Qty 
		FROM FACT_TRANSACTIONS AS FT 
        left join DIM_CUSTOMER AS DC ON FT.IDCustomer=DC.IDCustomer
        WHERE FT.IDCustomer IN 
		(
		SELECT TOP 10 IDCustomer 
		FROM FACT_TRANSACTIONS 
		GROUP BY IDCustomer 
		ORDER BY SUM(TotalPrice) DESC)
        GROUP BY DC.Customer_Name, YEAR(FT.DATE)
        )T2
        ON T1.Customer_Name=T2.Customer_Name AND T2.YEAR=T1.YEAR-1 

--END

	
